package juc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.Executor;
public class Juc01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer>list =new ArrayList();//Arraylist 线程不安全
		List<Integer>ls =Collections.synchronizedList(list);//将Arraylist转换成线程安全
		Executor pool =Executors.newCachedThreadPool();
		
		pool.execute(()->{
			for(int i=0;i<3;i++) {
				for(int t=0;t<5;t++) {
					
					try{
						ls.add(t);
						Thread.sleep(200);
						System.out.println("Thread"+Thread.currentThread().getName());
					}
					catch (Exception e) {
						e.printStackTrace();
					}
					
				}
				
			}
		
		});

	}

}
