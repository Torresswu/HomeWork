package demo1;

public class run1 {

	public static void main(String[] args) {
		
		run r =(str)->System.out.println(str+"qifei");
		r.run("wubo");

	}

}
