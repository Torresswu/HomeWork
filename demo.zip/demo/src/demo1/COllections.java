package demo1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class COllections {
	
	Car car =new Car();
	public static void main(String[] args) {
		List<Car>list =new ArrayList<>();
		
		list.add(new Car("benz",2121.2));
		list.add(new Car("BWM", 212121.1));
		list.add(new Car("pad", 211.1));
		list.add(new Car("sds", 121.1));
				
		list=list.stream().sorted((x,y)->x.getPrice()>y.getPrice()?1:-1).collect(Collectors.toList());
	    
		System.out.println(list.toString());
		
//		Collections.sort(list, new Comparator<Car>() {
//			
//			public int compare(Car o1,Car o2) {
//				return 	(int) (o1.getPrice()-o2.getPrice());
//			}
//		});
//	    System.out.println(list);
	}
@Override
public String toString() {
	return "Car"+car.getName()+","+car.getPrice();
}
	
}
