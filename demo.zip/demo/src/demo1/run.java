package demo1;
@FunctionalInterface
public interface run {

	public void run(String str);
}
