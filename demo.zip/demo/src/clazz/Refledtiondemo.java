package clazz;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

import clazz.entity.Car1;
@Controller
public class Refledtiondemo {

	public static void main(String[] args) throws Exception {
		
//		Class<Car> clazz =Car.class;
//		Car c=clazz.newInstance();
//		c.setName("BWM");
		
		Car1 c= new Car1();
		c.setName("BWnm");
		c.setPrice(2231.1);
			
//		Class<Car1>clazz =Car1.class;
//		Field field =clazz.getDeclaredField("name");
//         field.setAccessible(true);
//		 field.set(c, "Benz");
//		 
//		 System.out.println(c.getName());
		 
		 Class<?extends Car1> cl =Car1.class;
//		 Method []m=cl.getDeclaredMethods();
//		 
//		 for(Method ms:m) {
//			 
//			 System.out.println(ms);
//		 }
		 Method m =cl.getDeclaredMethod("runner",String.class);//获取有参方法,反射输出.
		  m.invoke(c, "benz");
//		
//        Field f[]	=	clazz.getDeclaredFields();
//		for (Field o:f) {
//	o.setAccessible(true);//可操作才能获取结果
//			System.out.println(o.get(c));
//		}
		
	}
}
