package thread;

public class Synchronized02 extends Thread {
    private Synchronized01 s;
    private String name;
    
    public Synchronized02(Synchronized01 s) {
    	this.s=s;
    }
    public Synchronized02(Synchronized01 s,String name) {
    	this.s=s;
    	this.name=name;
    	
    }

	@Override
	public void run() {
		
		if(this.s.getNum()>0) {
			try{
				this.s.ticket(this.getName());
				sleep(300);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	

}
