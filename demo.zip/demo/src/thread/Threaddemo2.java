package thread;

public class Threaddemo2 implements Runnable{
	@Override
	public void run() {
		// TODO Auto-generated method stub
		for(int i=0;i<3;i++) {
			System.out.println(Thread.currentThread().getName() +i);
		}
	}

	public static void main(String[] args) {
		Thread t1 =new Thread(new Threaddemo2() );
		Thread t2 =new Thread(new Threaddemo2() );
       t1.start();
       t2.start();
	}

}
