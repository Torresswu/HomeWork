package thread;

public class Threaddemo1 extends Thread {

	@Override
	public void run() {
		for(int i=0;i<3;i++) {
			System.out.println(this.getName() +i);
		}
	}
	

	public static void main(String[] args) {
		Thread t1 =new Threaddemo1();
		Thread t12 =new Threaddemo1();
		t1.start();
		t12.start();
	}

}
