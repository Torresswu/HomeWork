package thread;

import java.util.concurrent.Callable;

public class Threaddemo3 implements Callable<Integer>{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
@Override
public Integer call() throws Exception {
	// TODO Auto-generated method stub
	return null;
}

}
