package thread;

public class Threaddemo4 extends Thread{
	 public static volatile boolean f =false;//线程可见性 通过volatile 显示

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Thread t1 =new thread01();
        Thread t2 =new thread02();
        t1.start();
        t2.start();
        
	}
	static class thread01 extends Thread{
@Override
public void run() {
	// TODO Auto-generated method stub
	while(true) {
		if(f) {
			System.out.println(this.getName()+" ," +f);
		}
	}
	
}
	}
	static class thread02 extends Thread{
		@Override
		public void run() {
			// TODO Auto-generated method stu
			try{
				sleep(1000);
				f=true;
				System.out.println(this.getName()+"线程休眠"+f);
			 
			}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			
		}
			}
}
