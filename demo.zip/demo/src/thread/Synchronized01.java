package thread;

public class Synchronized01 {
private int num =100;

public  void ticket(String name) {
	System.out.println(name + " 剩余票数"+","+ (--num));
}

public int getNum() {
	return num;
}

}
