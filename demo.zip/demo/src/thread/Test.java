package thread;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Synchronized01 s1 =new Synchronized01();
		
		Thread t1 =new Synchronized02(s1);
		t1.setName("A");
		Thread t2 =new Synchronized02(s1);
		t2.setName("B");
		Thread t3 =new Synchronized02(s1);
		t3.setName("C");
		
		
		t1.start();
		t2.start();
		t3.start();
		
	}

}
